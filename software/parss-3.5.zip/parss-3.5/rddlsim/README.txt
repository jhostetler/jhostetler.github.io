RDDLSim -- A simulator for the relational dynamic influence diagram
           language (RDDL).

Copyright (C) 2010, Scott Sanner (ssanner@gmail.com) and
                    Sungwook Yoon (sungwook.yoon@gmail.com)


General Information
===================

LICENSE.txt:  GPLv3 license information for RDDLSim source and alternate
              license information for redistibuted 3rd party software

INSTALL.txt:  RDDLSim installation and execution instructions

PROTOCOL.txt: RDDLSim client/server protocol
