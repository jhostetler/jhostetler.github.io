package rddl.competition;

public class RDDLXMLException extends Exception {

	public RDDLXMLException(String s) {
		super(s);
	}
}
