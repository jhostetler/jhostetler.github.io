PARSS -- An implementation of the Progressive Abstraction Refinement for Sparse 
		 Sampling (PARSS) algorithm, with test domains and supporting software.

=== Introduction ===

This software implements abstract Forward Search Sparse Sampling (FSSS) and
the PARSS algorithm described in the paper,

@inproceedings{hostetler2015progressive,
  title={Progressive Abstraction Refinement for Sparse Sampling},
  author={Hostetler, Jesse and Fern, Alan and Dietterich, Thomas},
  booktitle={Conference on Uncertainty in Artificial Intelligence (UAI)},
  year={2015}
}

The code in package edu.oregonstate.eecs.mcplan.* was written by 
Jesse Hostetler (jessehostetler@gmail.com).

		 
=== Building ===

Requirements:
	java >= 1.7
	javac >= 1.7
	Apache ant (tested with 1.9.6)
	
Execute 'ant' from the root directory to compile.


=== Running ===

Program arguments are specified in a .csv file. See 'test.csv' for an example.

To run the test cases, execute:
	java -ea -jar parss.jar test.csv

It is recommended that you enable assertions (option '-ea'). You may also need
to enlarge the heap with '-Xmx'.

For an input file 'test.csv' with N separate experiments defined, a directory
'test' will be created containing 'test/data_i.csv' for i = 0..(N-1). A small
amount of summary information is also printed to stdout.


=== Problem domains ===

The following problem domains are implemented:
	advising:
		Generalized version of the IPC "advising" problem.
	crossing:
		IPC "crossing traffic"
	elevators:
		IPC "elevators"
	racegrid:
		The classic "racetrack" problem
	relevant_irrelevant:
		A toy problem with controllable levels of relevant and irrelevant
		stochastic branching
	sailing:
		Variations on the "sailing" problem, which has become a de facto
		standard for MCTS algorithms
	saving:
		Toy problem designed to make PARSS look good
	spbj:
		Spanish Blackjack
	tamarisk:
		IPC "tamarisk"
	tetris:
		An AI research version of the Tetris video game
	weinstein_littman:
		Counterexample to open-loop online planning
		
RDDL domains:
	The domains "advising", "crossing", "elevators", and "tamarisk" are from
	the IPC 2014. We have implemented these domains by hand because the RDDL
	simulator is very slow. But, they still read the RDDL files to get the
	domain parameters. We use the RDDL code provided with the IPC domains for
	this purpose.


=== Input file format ===

PARSS has a lot of parameters, which it reads from an input file. The input
file is a comma-separated value (.csv) file. See 'test.csv' for an example.

There are no default parameter values.

Fields:
	root_directory			: String	
		Paths are calculated relative to this
	domain					: String	
		{"advising", "crossing", "elevators", "racegrid", "relevant_irrelevant",
		"sailing", "saving", "spbj", "tamarisk", "tetris", "weinstein_littman"}
	rddl.domain				: String	
		Path to RDDL domain spec.
		Required if domain in {"advising", "crossing", "elevators", "tamarisk"}
	rddl.instance			: String
		Path to RDDL instance spec.
		Required if domain in {"advising", "crossing", "elevators", "tamarisk"}
	ss.abstraction			: String	{"ground", "par", "random", "top"}
		ground: FSSS with no abstraction
		par:	PARSS algorithm
		random:	FSSS with random abstraction
		top:	FSSS with top abstraction
	ss.width				: int	>= 1
		Sparse sampling width
	ss.depth				: int	>= 1
		Sparse sampling depth.
		'depth' = 1 means just the root node. 'depth' = 2 means one action,
		and so on.
	ss.budget_type			: String	{"samples", "time"}
		Type of budget to use.
	ss.budget				: int
		Represents samples or milliseconds
	par.classifier			: String	{"decision_tree", "random_partition"}
		Classifier used to represent refineable state abstraction.
		Required if 'ss.abstraction' = "par"
		decision_tree: 		Build decision tree greedily
		random_partition:	Randomly split instances
	par.priority			: String	{"bf", "uniform", "variance"}
		Priority ordering for node selection for refinement.
		Required if 'ss.abstraction' = "par"
		bf:			Breadth-first
		uniform:	Uniformly at random
		variance:	Highest Q-function variance first
	par.split_evaluator 	: String	{"heuristic"}
		If par.classifier == decision_tree, the method used for evaluating
		splits during greedy decision tree building.
		heuristic:	the only supported value
	par.heuristic			: String	{"astar", "L1"}
		If par.split_evaluator == heuristic, the ranking heuristic.
		astar:	Encourage a*-irrelevance
		L1:		Encourage small L1 distance
	par.split_evaluator.size_regularization		: float	>= 0
		Larger numbers encourage creating new partitions with roughly equal
		size. Recommended setting is 0.
	random_abstraction.k	: int	>= 1
		If par.classifier = random, the maximum number of parts in a random
		partition.
	Ntest_games				: int
		Number of episodes to average over when calculating average return.
	error_rate_limit		: float [0, 1]
		If more than Ntest_games*error_rate_limit episodes fail due to a
		recoverable error, the experiment will be stopped. Any completed
		episodes will still be logged. Set to 0 to fail immediately after
		an error; set to 1 to attempt Ntest_games regardless of errors.
	discount				: float			@deprecated
		Discount factor. NOTE: Not respected by most (all?) domains.
	seed.world				: int
		The RNG seed used for "real world" random events (ie. when executing
		the tree search policy).
	seed.sim				: int
		The RNG seed used for "simulation" events (ie. when building the 
		search tree).
	ss.use_close			: boolean
		Enables memory-saving optimization where ground state nodes are freed
		once we can guarantee we won't need to sample any more successors.
		It is useful to turn this off when debugging search trees so that you
		can see all of the primitive nodes. Should be TRUE normally.
	log.domain				: String
		{"none", "error", "warn", "info", "debug", "trace", "all"}
		Controls log verbosity for messages pertaining to the domain.
	log.execution			: boolean
		Toggles logging of the "real world" execution path.
	log.search				: String
		{"none", "error", "warn", "info", "debug", "trace", "all"}
		Controls log verbosity for message pertaining to the search algorithm.
	log.visualization		: boolean
		Must be FALSE. (Domain visualizations have not been kept up to date).
	racegrid.T				: int
		Racegrid time step limit.
	racegrid.circuit		: String {"bbs_small", "bbs_large"}
		Racegrid track layout. The two problems from the original paper are
		implemented.
	racegrid.slip			: float [0, 1]
		Racegrid action error rate.
	racegrid.scale			: int	>= 1
		Scale the racetrack up to 'scale' times normal size while retaining
		the same layout.
	saving.T				: int
		Saving time step limit.
	saving.price_min		: int	<= price_max
		Minimum "sell" price.
	saving.price_max		: int	>= price_min
		Maximum "sell" price.
	saving.maturity_period	: int	>= 1
		Time steps to wait after "Invest" before "Sell" is available. If 1, 
		"Sell" is available at the next time step after "Invest".
	saving.invest_period	: int	>= 1
		Number of time steps for which "Sell" is available.
	saving.loan_period		: int	>= 1
		Number of time steps before loan is repaid.
	advising.max_grade		: int	>= 1
		Maximum grade. The minimum grade is 0.
	advising.passing_grade	: int	>= 1	<= max_grade
		Minimum grade for a required course to count as completed.
	relevant_irrelevant.T	: int	>= 1
		Time step limit.
	relevant_irrelevant.nr	: int	>= 1
		Cardinality of "relevant" state variable.
	relevant_irrelevant.ni	: int	>= 1
		Cardinality of "irrelevant" state variable.
	weinstein_littman.nirrelevant	: int	>= 1
		Cardinality of "irrelevant" state variable.
	sailing.T				: int	>= 1
		Time step limit.
	sailing.V				: int	>= 1
		Cardinality of "wind velocity" state variable.
	sailing.world			: String 	{"empty", "random"}
		Sailing world. "Random" has randomly place obstacles.
	sailing.dim				: int	>= 1
		Height/width of sailing grid.
	sailing.p				: float	[0, 1]
		If world = "random", probability that each cell is an obstacle.
	tetris.T				: int	>= 1
		Time step limit.
	tetris.Nrows			: int	>= 1
		Number of rows in Tetris game.
	tetris.repr				: String	{"ground", "bertsekas"}
		State representation. "Ground" represents occupancy of each grid cell,
		while "bertsekas" is the (relatively standard) "Bertsekas features"
		set.
		

=== Implementing new domains ===

To implement a new domain, you will need to implement
	FsssModel<YourState, YourAction>

See the other domains for examples. You will then need to modify
FsssJairExperiments to recognize your new domain and get its parameters from
the input file.


=== License ===

* PARSS is licensed under the FreeBSD software license (see LICENSE.txt)
* The components in the 'rddlsim' directory are licensed under GPLv3. See
rddlsim/LICENSE.txt for details.
